


const Products =`<!-- CONTENT -->
  <div class="Productos w-full   flex-col justify-center items-start gap-[106px] ">

    
    <div class="LineaProduto  flex-col justify-start items-start gap-4 inline">
  <!-- Producto title -->

      <div class="Topo w-full justify-between items-center inline-flex">
        <div class="Productos text-[#464646] text-[32px] font-bold font-['Raleway']">Productos</div>
        <div class="Botao justify-start items-center gap-2 flex">
          <div class="VerTodo text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver todo</div>
          <div class="ArrowBackBlack24dp1 w-6 h-6 "> logo</div>
        </div>
      </div>
        <!-- Producto title -->
<!-- Products -->
      <div class="Produtos justify-between items-start gap-4  p-4">
        <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
          <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
            <img class="img self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174"  alt="Product"/>
          </div>
          <div class="ProductoXyz self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Producto XYZ</div>
          <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
          <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
        </div>
        <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
          <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
            <img class="UnsplashEprfeHbnjo self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
          </div>
          <div class="ProductoXyz self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Producto XYZ</div>
          <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
          <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
        </div>
        <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
          <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
            <img class="UnsplashKegtodvn0l4 self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
          </div>
          <div class="ProductoXyz self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Producto XYZ</div>
          <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
          <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
        </div>
        <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
          <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
            <img class="Unsplash4ohkk555s1a self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
          </div>
          <div class="ProductoXyz self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Producto XYZ</div>
          <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
          <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
        </div>
        <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
          <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
            <img class="UnsplashR8l1l9rn198 self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
          </div>
          <div class="ProductoXyz self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Producto XYZ</div>
          <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
          <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
        </div>
        <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
          <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
            <img class="Unsplash1vv1mrafd7a self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
          </div>
          <div class="ProductoXyz self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Producto XYZ</div>
          <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
          <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
        </div>
      </div>
    </div>
    <div class="Produtos self-stretch justify-start items-start gap-4  p-4 ">
      <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
        <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
          <img class="UnsplashFmpOcze3ay self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
        </div>
        <div class="CamisaAtari self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Camisa Atari</div>
        <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
        <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
      </div>
      <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
        <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
          <img class="UnsplashBugaiazysh0 self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
        </div>
        <div class="CamisaSnes self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Camisa SNES</div>
        <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
        <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
      </div>
      <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
        <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
          <img class="UnsplashSyvyZkwaxu self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
        </div>
        <div class="ControlYConsolaXyz self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Control y consola XYZ</div>
        <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
        <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
      </div>
      <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
        <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
          <img class="UnsplashJmt6brgbuxu self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
        </div>
        <div class="ControlYConsolaXyz self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Control y consola XYZ</div>
        <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
        <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
      </div>
      <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
        <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
          <img class="UnsplashMxvkwpijals self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
        </div>
        <div class="ControlYConsolaXyz self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Control y consola XYZ</div>
        <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
        <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
      </div>
      <div class="Produto flex-col justify-start items-start gap-2 inline-flex">
        <div class="Skill w-44 h-[174px] bg-white flex-col justify-end items-start gap-2 flex">
          <img class="UnsplashR27umxaeldc self-stretch grow shrink basis-0" src="https://via.placeholder.com/176x174" />
        </div>
        <div class="ProductoXyz self-stretch text-[#464646] text-sm font-medium font-['Raleway']">Producto XYZ</div>
        <div class="6000 self-stretch text-[#464646] text-base font-bold font-['Raleway']">$ 60,00</div>
        <div class="VerProducto text-[#2a7ae4] text-base font-bold font-['Raleway']">Ver producto</div>
      </div>
    </div>
  </div>
  <!-- CONTENT -->
`




document.querySelector<HTMLDivElement>('#content_prod_cp')!.innerHTML = Products;



  export default Products