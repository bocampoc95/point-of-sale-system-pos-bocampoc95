


const Acess =`<!-- Button Accessibility -->
<div class="fixed bottom-3/4 right-0 w-[40px] h-[40px] flex items-center justify-center">
  <div class="bg-red-600 w-full h-full rounded-full shadow-lg">
    <img class="w-8 h-8" src="/Acess.svg" alt="Accessibility Button" />
  </div>
</div>
<!-- Button Accessibility -->`
export default Acess


